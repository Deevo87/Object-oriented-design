package pl.edu.agh.dronka.shop.model;

public enum MusicGenre {
    ROCK,
    CLASSIC,
    PUNK,
    RAP,
    HIPHOP,
    POP,
}
